package cs_176.polymorphism;

public interface Moveable {
	//TODO: add method
	
	public void move (double detlax, double detlay); 

}