package cs_176.polymorphism;

import java.util.Arrays;


public class ShapeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		//Create an array of Circle type to store the following 3 circle objects
		Circle[] circle = new Circle[3]; 
		
		
		//Circle 1: center (0, 1) and radius: 2
		circle[0] = new Circle(0,1,2);  
		
		//Circle 2: center (3, 2) and radius: 4
		circle[1] = new Circle(3,2,4);  
		
		//Circle 3: center (4, 5) and radius: 1
		 
		circle[2] = new Circle(4,5,1);  
		
		//Call the Arrays.sort() method to sort the above three circles 
		
		
		Arrays.sort(circle);
		
		System.out.println("circle array:");
		System.out.println();	
		
		//and print out the sorted array.
		System.out.println(Arrays.toString(circle));
			
		System.out.println();
		
		//Create an array of Rectangle type to store the following 3 rectangle objects.
			
		Rectangle[] rect = new Rectangle[3];  
		
		//Rectangle 1: top-left corner: (5, 10), length: 20, width: 3
		rect [0] = new Rectangle (5,10,20,3);  
		//Rectangle 2: top-left corner: (4, 8), length: 5, width: 2
		rect [1] = new Rectangle (4,8,5,2); 
		//Rectangle 3: top-left corner: (6, 9), length: 8, width: 10
		rect [2] = new Rectangle (6,9,8,10);  
		
		//Call the Arrays.sort() method to sort the above three rectangles 
			Arrays.sort(rect);
			
			System.out.println("rectangle array:");   
			System.out.println();
	  
			//and print out the sorted array.
			System.out.println(Arrays.toString(rect));
			
			System.out.println();
			
			//Call the move method on Circle 1 so that its new center is (3, 2) 
			
			circle[0].move(-1,-3);
	       
	       
	       System.out.println("circle 1:");
	       System.out.println();
	       System.out.println(circle[0].toString());
	       System.out.println();
	       
	       //Call the move method on Rectangle 2 to move it along x- and y-coordinates by 2 and 3
	      // units 
	       rect[1].move(2,3);
	      
	       System.out.println("rect 2:");
	       System.out.println();
	       System.out.println(rect[1]);
	       System.out.println();
	           
	       //Create two Cuboids:
	       // Cuboid 1: top-left corner: (5, 10, 2), length: 20, width: 3, height: 2
	       Cuboid cuboid1 = new Cuboid(5, 10, 2, 20, 3, 2);
	       //Cuboid 2: top-left corner: (4, 8, 6), length: 5, width: 2, height: 10
	       Cuboid cuboid2 = new Cuboid(4,8,6,5,2,10);
	       
	       
	       
	       System.out.println("  1 = cuboid 1 has a bigger vol. than cuboid 2\n"
	       		+ " -1 = cuboid 1 has a smaller vol. than cuboid 2 \n"
	       		+ "  0 = Cuboid 1 and Cuboid 2 have same vol.");
	       System.out.println(); 
	       
	       //Call compareto method on Cuboid 1 to compare with Cuboid 2 
	       //and print which has a larger volume.
	       System.out.println(cuboid1.compareTo(cuboid2));
		
	
			}
		}
	
