package cs_176.polymorphism;

public class Shape {
	public Shape() {
	
	}
}
